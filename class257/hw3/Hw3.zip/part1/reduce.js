function(key, value) { 
	return value.reverse();
}