part 2
	environment requirements:
		php7.2
	
	demo example:
		php BtreeAppendExperiment.php db
		

	
























