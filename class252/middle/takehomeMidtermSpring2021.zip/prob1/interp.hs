{-
  Name: <Your name here>
  Class: CS 252
  Description: CS 252, Spring 2021, Take home exam, problem #1.
-}


module Interp (
  Expression(..),
  testProgram,
  run
) where

import Data.Map (Map)
import qualified Data.Map as Map

-- We represent variables as strings.
type Variable = String

-- The store is an associative map from variables to values.
-- (The store roughly corresponds with the heap in a language like Java).
type Store = Map Variable Integer

data Expression =
    Num Integer                     -- n
  | Set Variable Expression         -- set x e
  | Read Variable                   -- read x
  | Loop Expression Expression      -- loop e1 e2
  | Inc Expression                  -- inc e
  | Test Expression Expression      -- test e1 e2
  | Then Expression Expression      -- e1 then e2
  | Crash
  deriving (Show)


-- Implement this function according to the specified semantics
evaluate :: Expression -> Store -> Maybe (Integer, Store)
evaluate (Num n) s = Just (n, s)
evaluate Crash _ = Nothing
evaluate _ _ = error "TBD"


-- Evaluates a program with an initially empty state
run :: Expression -> Maybe (Integer, Store)
run prog = evaluate prog Map.empty

-- The same as run, but only returns the Store
testProgram :: Expression -> Maybe Store
testProgram prog = case run prog of
  Nothing -> Nothing
  Just (_, s) -> Just s


